package dev.localhost.gui;
import studio.dreamys.icarus.component.Window;
import studio.dreamys.icarus.component.engine.GuiEngine;
import studio.dreamys.icarus.component.enums.Position;
import dev.localhost.module.Module;
import dev.localhost.Localhost;
public class ClickGui extends GuiEngine {
    public ClickGui() { super('localhost', 'ClickGUI'); }
    public void rebuild() {
        Window combat   = new Window('Combat',   Position.LEFT);
        Window movement = new Window('Movement', Position.LEFT);
        Window world    = new Window('World',    Position.LEFT);
        Window bypass   = new Window('Bypass',   Position.LEFT);
        for (Module m : Localhost.modules.all()) {
            String cat = m.category();
            Window target = cat.equals('Combat') ? combat : cat.equals('Movement') ? movement : cat.equals('World') ? world : bypass;
            m.attach(target);
        }
    }
}
