package dev.localhost.module.world;
import dev.localhost.module.Module;
import studio.dreamys.icarus.component.Window;
import net.minecraft.client.Minecraft;
import net.minecraft.block.BlockBed;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
public class BedNuker extends Module {
    private final Minecraft mc = Minecraft.getMinecraft();
    private int tick;
    public BedNuker() { super('BedNuker', 0); }
    public String category() { return 'World'; }
    public void onEnable()  { tick = 0; }
    public void onDisable() {}
    public void attach(Window w) { w.addCheckbox(this); }
    public void onTick() {
        if (++tick % 4 != 0) return;
        if (mc.thePlayer == null) return;
        BlockPos origin = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY, mc.thePlayer.posZ);
        for (int dx = -8; dx <= 8; dx++) {
            for (int dy = -3; dy <= 3; dy++) {
                for (int dz = -8; dz <= 8; dz++) {
                    BlockPos p = origin.add(dx, dy, dz);
                    if (mc.theWorld.getBlockState(p).getBlock() instanceof BlockBed) {
                        mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.START_DESTROY_BLOCK, p, EnumFacing.UP));
                        mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, p, EnumFacing.UP));
                    }
                }
            }
        }
    }
}
