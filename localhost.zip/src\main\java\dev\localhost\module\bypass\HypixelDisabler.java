package dev.localhost.module.bypass;
import dev.localhost.module.Module;
import studio.dreamys.icarus.component.Window;
public class HypixelDisabler extends Module {
    public HypixelDisabler() { super('HypixelDisabler', 0); }
    public String category() { return 'Bypass'; }
    public void onEnable()  {}
    public void onDisable() {}
    public void onTick()    {}
    public void attach(Window w) { w.addCheckbox(this); }
}
