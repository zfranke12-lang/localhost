package dev.localhost.module;
import dev.localhost.module.combat.KillAura;
import dev.localhost.module.movement.Scaffold;
import dev.localhost.module.world.BedNuker;
import dev.localhost.module.bypass.HypixelDisabler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import java.util.ArrayList;
import java.util.List;
public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();
    public ModuleManager() {
        modules.add(new KillAura());
        modules.add(new Scaffold());
        modules.add(new BedNuker());
        modules.add(new HypixelDisabler());
        MinecraftForge.EVENT_BUS.register(this);
    }
    public List<Module> all() { return modules; }
    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        for (Module m : modules) if (m.enabled) m.onTick();
    }
}
