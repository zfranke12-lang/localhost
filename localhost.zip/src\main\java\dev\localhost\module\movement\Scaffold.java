package dev.localhost.module.movement;
import dev.localhost.module.Module;
import dev.localhost.util.RotationUtil;
import studio.dreamys.icarus.component.Window;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemBlock;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;
public class Scaffold extends Module {
    public boolean snap = true;
    private final Minecraft mc = Minecraft.getMinecraft();
    public Scaffold() { super('Scaffold', 0); }
    public String category() { return 'Movement'; }
    public void onEnable()  {}
    public void onDisable() {}
    public void attach(Window w) {
        w.addCheckbox(this);
        w.addCheckbox(this, 'snap', v -> snap = v);
    }
    public void onTick() {
        if (mc.thePlayer == null) return;
        if (!(mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemBlock)) return;
        BlockPos below = new BlockPos(mc.thePlayer.posX, mc.thePlayer.posY - 1.0, mc.thePlayer.posZ);
        if (!mc.theWorld.isAirBlock(below)) return;
        float[] rot = faceRotation(below);
        mc.thePlayer.rotationYaw   = rot[0];
        mc.thePlayer.rotationPitch = rot[1];
        RotationUtil.movementFix(rot[0]);
        BlockPos against = below.down();
        if (mc.theWorld.isAirBlock(against)) return;
        Vec3 hit = new Vec3(against.getX() + 0.5, against.getY() + 1.0, against.getZ() + 0.5);
        mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, mc.thePlayer.getHeldItem(), against, EnumFacing.UP, hit);
    }
    private float[] faceRotation(BlockPos pos) {
        double dx = pos.getX() + 0.5 - mc.thePlayer.posX;
        double dz = pos.getZ() + 0.5 - mc.thePlayer.posZ;
        float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        return new float[]{ yaw, 80.0f };
    }
}
