package dev.localhost.util;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.util.MathHelper;
public class RotationUtil {
    private static final Minecraft mc = Minecraft.getMinecraft();
    public static float[] getRotationsTo(Entity target) {
        double dx = target.posX - mc.thePlayer.posX;
        double dz = target.posZ - mc.thePlayer.posZ;
        double dy = (target.posY + target.getEyeHeight()) - (mc.thePlayer.posY + mc.thePlayer.getEyeHeight());
        double dist = MathHelper.sqrt_double(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, dist));
        return new float[]{ yaw, pitch };
    }
    public static void movementFix(float serverYaw) {
        float forward = mc.thePlayer.movementInput.moveForward;
        float strafe  = mc.thePlayer.movementInput.moveStrafe;
        float yaw     = mc.thePlayer.rotationYaw - serverYaw;
        float sin     = MathHelper.sin(yaw * (float)Math.PI / 180f);
        float cos     = MathHelper.cos(yaw * (float)Math.PI / 180f);
        mc.thePlayer.movementInput.moveForward = forward * cos + strafe * sin;
        mc.thePlayer.movementInput.moveStrafe  = strafe * cos - forward * sin;
    }
}
