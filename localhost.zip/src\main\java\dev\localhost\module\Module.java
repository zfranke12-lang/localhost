package dev.localhost.module;
import studio.dreamys.icarus.component.Window;
public abstract class Module {
    public String name; public boolean enabled; public int key;
    public Module(String name, int key) { this.name = name; this.key = key; }
    public abstract String category();
    public abstract void onEnable();
    public abstract void onDisable();
    public abstract void onTick();
    public abstract void attach(Window w);
}
