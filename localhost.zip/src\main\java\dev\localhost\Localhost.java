package dev.localhost;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import dev.localhost.module.ModuleManager;
import dev.localhost.gui.ClickGui;
@Mod(modid = 'localhost', name = 'localhost', version = '1.0', clientSideOnly = true)
public class Localhost {
    public static ModuleManager modules;
    public static ClickGui gui;
    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        modules = new ModuleManager();
        gui = new ClickGui();
    }
}
