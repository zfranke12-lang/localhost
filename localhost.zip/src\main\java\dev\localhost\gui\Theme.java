package dev.localhost.gui;
public class Theme {
    public static final int ACCENT       = 0xFFB48CFF;
    public static final int BG           = 0xFF141418;
    public static final int PANEL        = 0xFF1C1C24;
    public static final int ROW          = 0xFF24242E;
    public static final int TEXT         = 0xFFDCDCE6;
    public static final int PANEL_WIDTH  = 340;
    public static final int ROW_HEIGHT   = 18;
}
