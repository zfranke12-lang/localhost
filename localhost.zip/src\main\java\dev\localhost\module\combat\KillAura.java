package dev.localhost.module.combat;
import dev.localhost.module.Module;
import dev.localhost.util.RotationUtil;
import studio.dreamys.icarus.component.Window;
import studio.dreamys.icarus.component.Slider;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
public class KillAura extends Module {
    public double cps = 10.0;
    public double rotationSpeed = 60.0;
    private long lastAttack;
    private final Minecraft mc = Minecraft.getMinecraft();
    public KillAura() { super('KillAura', 0); }
    public String category() { return 'Combat'; }
    public void onEnable()  { lastAttack = 0; }
    public void onDisable() {}
    public void attach(Window w) {
        w.addCheckbox(this);
        w.addSlider(this, 'cps', new Slider(1, 20, (float) cps, v -> cps = v));
        w.addSlider(this, 'rotationSpeed', new Slider(1, 180, (float) rotationSpeed, v -> rotationSpeed = v));
    }
    public void onTick() {
        EntityLivingBase target = findTarget();
        if (target == null) return;
        float[] rot = RotationUtil.getRotationsTo(target);
        float step = (float) rotationSpeed;
        float yaw   = approach(mc.thePlayer.rotationYaw, rot[0], step);
        float pitch = approach(mc.thePlayer.rotationPitch, rot[1], step);
        RotationUtil.movementFix(yaw);
        mc.thePlayer.rotationYaw   = yaw;
        mc.thePlayer.rotationPitch = pitch;
        if (System.currentTimeMillis() - lastAttack >= (long)(1000.0 / cps)) {
            mc.playerController.attackEntity(mc.thePlayer, target);
            mc.thePlayer.swingItem();
            lastAttack = System.currentTimeMillis();
        }
    }
    private EntityLivingBase findTarget() {
        EntityLivingBase best = null;
        double bestDist = 4.2;
        for (Object o : mc.theWorld.loadedEntityList) {
            if (!(o instanceof EntityPlayer)) continue;
            EntityPlayer p = (EntityPlayer) o;
            if (p == mc.thePlayer || p.isDead) continue;
            double d = mc.thePlayer.getDistanceToEntity(p);
            if (d < bestDist) { bestDist = d; best = p; }
        }
        return best;
    }
    private static float approach(float cur, float tgt, float step) {
        float d = ((tgt - cur + 540f) % 360f) - 180f;
        if (Math.abs(d) <= step) return tgt;
        return cur + Math.copySign(step, d);
    }
}
